# Created By
Kevin Octavianus Halim

This is a Console App

#### Created using :

Visual Studio 2022 v.17.9.3

.NET Framework 6.0

### The Output Results Are Summarized in OUTPUT.pdf